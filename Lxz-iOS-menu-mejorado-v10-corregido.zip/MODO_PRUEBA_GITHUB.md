# Modo de prueba Patches (solo interfaz)

Este proyecto incluye un workflow manual **Panther Patches - Demo IPA** en GitHub Actions. Sube el contenido descomprimido a un repositorio, abre Actions, selecciona el workflow y pulsa Run workflow. Descarga el artifact `Panther-Patches-DEMO-unsigned`, descomprímelo y firma la IPA con GBox.

Esta versión muestra directamente la interfaz `PatchProjectsView` al arrancar, sin calculadora ni pantalla de keys. **No crea una sesión, no valida una key, no concede permisos de administrador ni acceso a recursos protegidos del servidor.** Algunas operaciones del menú podrían requerir sesión y no funcionar.

La compilación no ha sido probada en Xcode en este entorno. Es una IPA de prueba, NO una .dylib para inyectar. El workflow original `build-ipa.yml` permanece intacto y conserva el flujo normal.
